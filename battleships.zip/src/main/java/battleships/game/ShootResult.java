package battleships.game;

public enum ShootResult {

    MISS,
    HIT,
    HIT_AND_SINK;
}