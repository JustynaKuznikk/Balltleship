package battleships.game;

public enum GameResult {

    FIRST_PLAYER_WON,
    SECOND_PLAYER_WON,
    DRAW,
    NOT_FINISHED_YET;
}